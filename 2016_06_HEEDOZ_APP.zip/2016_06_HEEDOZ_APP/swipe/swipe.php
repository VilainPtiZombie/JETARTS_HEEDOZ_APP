  <body>

    <nav id="menu" class="menu">
      <div class="menu_icon">
        <img src="img/profil.png" style="width:30%">
        <a href="profil.php">Mon Profil</a>
      </div>
      <div class="menu_icon">
        <img src="img/profil.png" style="width:30%">
        <a href="explore.php">Explorer</a>
      </div>
      <div class="menu_icon">
        <img src="img/profil.png" style="width:30%">
        <a href="categories.php">Catégories</a>
      </div>
      <div class="menu_icon">
        <img src="img/profil.png" style="width:30%">
        <a href="parametre.php">Paramètres</a>
      </div>
      <div class="menu_icon">
        <img src="img/profil.png" style="width:30%">
        <a href="#">Effacer la mémoire cache</a>
      </div>
      <div class="menu_icon">
        <img src="img/profil.png" style="width:30%">
        <a href="logout.php">Déconnexion</a>
      </div> 
    </nav>

    <main id="panel" class="panel">

    