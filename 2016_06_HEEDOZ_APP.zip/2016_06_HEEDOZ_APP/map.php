<!DOCTYPE html>
<html>
<?php 
include('header.php');
?>
<body>
 
    <div id='listings' class='listings'></div>

  <div id='map' class='map'> </div>
  <a href='#' id='geolocate' class='ui-button'>Find me</a>

<script src="js/index.js"></script>
  
</body>
</html>
