<!DOCTYPE html>
<html>
<?php 
include('header.php');
?>
<body>
    <div class="back_map">
        <a href="#"><img src="img/fleche_retour-02.png"></a>
        <h1 class="page_profil">heedoz</h1>
    </div>
  <div id='map' class='map'> </div>
  <a href='#' id='geolocate' class='ui-button'>Où suis-je ?</a>

<script src="js/index.js"></script>
  
</body>
</html>
