<?php
define('UPLOAD_FILE_PATH', realpath(dirname(__FILE__)) . "/upload/");
define('UPLOAD_URL_PATH', "upload/");